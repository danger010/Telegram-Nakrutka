<p align="center">
  <img src="https://1.bp.blogspot.com/-bMerZKbriRY/X0YzqiPFCsI/AAAAAAAAAP8/1GHlVlmMGcQsHu8cxeK1o5WkTe2VeXlDgCLcBGAsYHQ/s1652/Picture_20200826_152605754.jpg" width="470" height="150">
</p>

<p align="center"><img src="https://img.shields.io/badge/Version-1.01-brightgreen"></p>
<p align="center">
  <a href="https://github.com/termuxprofessor">
    <img src="https://img.shields.io/github/followers/th3unkn0n?label=Follow&style=social">
  </a>
  <a href="https://github.com/termuxprofessor/Telegram-Scraper-Adder">
    <img src="https://img.shields.io/github/stars/th3unkn0n/TeleGram-Group-Scraper?style=social">
  </a>
</p>
<p align="center">
  Telegram Scraper Adder
</p>
<p align="center">
  wtf, atlest just fuking ⭐ star ⭐ it
</p>

---

## • API Setup
* Go to http://my.telegram.org  and log in.
* Click on API development tools and fill the required fields.
* put app name you want & select other in platform Example :
* copy "api_id" & "api_hash" after clicking create app ( will be used in setup.py )

## • How To Install and Use In Termux

`$ pkg up -y`

`$ pkg install python -y`

`$ pkg install git`

`$ git clone https://github.com/termuxprofessor/TeleGram-Scraper-Adder`

`$ cd Telegram-Scraper-Adder`

* Install requierments & Setup Configuration File. ( apiID, apiHash )

`$ python setup.py`

* To Scare members from group.

`$ python scraper.py`

* Add Scarped members to your group. 

`$ python adder.py`

## • Watch Video Tutorial From Below
* https://youtu.be/hNztfzMMPOc
---

<p align="center">
  Follow Me On
</p>
<p align="center">
  <a href="https://www.youtube.com/c/TermuxProfessorYT">
    <img src="https://github.com/th3unkn0n/extra/blob/master/.img/yt.png" width="40" height="40">
  </a>
  <a href="https://www.instagram.com/termuxprofessor/">
    <img src="https://github.com/th3unkn0n/extra/blob/master/.img/ig.png" width="40" height="40">
</p>
